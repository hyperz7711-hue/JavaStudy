package com.kh.f_poly.model.vo;

public class CookBook extends Book {
	
//	- coupon : boolean // 요리학원쿠폰유무
//	+ CookBook()
//	+ CookBook(title:String, author:String,
//	publisher:String, coupon:boolean)
//	+ toString() : String	
	
	private boolean coupon;	
	
	public CookBook() {}
	public CookBook(String title, String author, String publisher, boolean coupon  ) {
		
		super(title,author, publisher );
		this.coupon = coupon;
		
	}
	
	public boolean isCoupon() {
		return coupon;
	}
	public void setCoupon(boolean coupon) {
		this.coupon = coupon;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}	

}
