package com.kh.f_poly.view;

import java.util.Scanner;

import com.kh.f_poly.model.vo.Book;
import com.kh.f_poly.model.vo.Member;
import com.kh.f_poly.common.InputValidator; // 입력오류 방지 체크로직 : 참조 자료
import com.kh.f_poly.controller.LibraryController;


public class LibraryMenu {
	
//	- lc : LibraryController // 초기화 생성
//	- sc : Scanner // 초기화 생성
//	+ mainMenu() : void
//	+ selectAll() : void
//	+ searchBook() : void
//	+ rentBook() : void	
	

	
	LibraryController lc = new LibraryController();
	Scanner sc = new Scanner(System.in);
	
	
	public LibraryController getLc() {
		return lc;
	}

	public void setLc(LibraryController lc) {
		this.lc = lc;
	}

	
	// 이름, 나이, 성별을 키보드로 입력 받은 후 Member 객체 생성
	 // LibraryController의 insertMember() 메소드에 전달
//	 ==== 메뉴 ==== // 무한 반복 실행
//	1. 마이페이지 // LibraryController의 myInfo() 호출하여 출력
//	2. 도서 전체 조회 // LibraryMenu의 selectAll() 호출
//	3. 도서 검색 // LibraryMenu의 searchBook() 호출
//	4. 도서 대여하기 // LibraryMenu의 rentBook() 호출
//	9. 프로그램 종료하기
//	메뉴 번호 :	

	    public void mainMenu() {
	        System.out.print("이름 : ");
	        String name = sc.nextLine();


	       
	        int age = InputValidator.getPositiveInt(sc, "나이 : "); // 입력시 양수값만 체크
//	        System.out.print("나이 : ");	    // 출제의도 표준 코딩    
	        // int age = sc.nextInt();  // 출제의도 표준 코딩

	        char gender = InputValidator.getAllowedChar(sc, "성별(M/F) : ", 'M', 'F'); // 입력시 M,F만 입력되었는지 체크
	       // char gender = sc.nextLine().toString().charAt(0);	 // 출제의도 표준 코딩       

	        
	        // 스캐너에서 입력받은 값을 멤버배열로 입력
	        lc.insertMember(new Member(name, age, gender));

            // 메뉴 보이기
	        while (true) {
	            System.out.println("\n==== 메뉴 ====");
	            System.out.println("1. 마이페이지");
	            System.out.println("2. 도서 전체 조회");
	            System.out.println("3. 도서 검색");
	            System.out.println("4. 도서 대여하기");
	            System.out.println("9. 프로그램 종료하기");
	            
	            int menu = InputValidator.getPositiveInt(sc, "메뉴 번호 : "); // 입력시 양수값만 체크
	            // System.out.print("메뉴 번호 : ");   // 출제의도 표준 코딩
	            //int menu = sc.nextInt(); // 출제의도 표준 코딩
	            //sc.nextLine();

	            switch (menu) {
	                case 1: System.out.println(lc.myInfo()); break;
	                case 2: selectAll(); break;
	                case 3: searchBook(); break;
	                case 4: rentBook(); break;
	                case 9: System.out.println("프로그램을 종료합니다."); return;
	                default: System.out.println("잘못 입력하였습니다.");
	            }
	        }
	    }

        // 전체 리스트를 배열로 출력 
	    public void selectAll() {
	        Book[] bList = lc.selectAll();
	        for (int i = 0; i < bList.length; i++) {
	            System.out.println(i + "번 도서 : " + bList[i]);
	        }
	    }

	 // “검색할 제목 키워드 : “ >> 입력 받음 (keyword)
	 // LibraryController의 searchBook() 에 전달
	 // 그 결과 값을 Book[] 자료형 searchList에 담아 검색 결과인 도서 목록 출력	    
	    
	    public void searchBook() {
	        System.out.print("검색할 제목 키워드 : ");
	        String keyword = sc.nextLine();
	        Book[] searchList = lc.searchBook(keyword);
            
	        for (Book b : searchList) {
	            if (b != null) System.out.println(b);
	        }
	    }

	 // 도서대여를 위해 도서번호를 알아야 하기 때문에 selectAll() 메소드 호출
	 // “대여할 도서 번호 선택 : ” >> 입력 받음 (index)
	 // LibraryController의 rentBook() 에 전달
	 // 그 결과 값을 result로 받고 그 result가
	 // 0일 경우 → “성공적으로 대여되었습니다.” 출력
	 // 1일 경우 → “나이 제한으로 대여 불가능입니다.” 출력
	 // 2일 경우 → “성공적으로 대여되었습니다. 요리학원 쿠폰이 발급되었으니 마이페이지에서 확인하세요” 출력	    
	    
	    public void rentBook() {
	        selectAll();
	        int index =  InputValidator.getPositiveInt(sc, "대여할 도서 번호 선택 : "); // 입력시 양수값만 체크
	        //System.out.print("대여할 도서 번호 선택 : ");	        
	        //int index = sc.nextInt();
	        int result = lc.rentBook(index);

	        switch (result) {
	            case 0: System.out.println("성공적으로 대여되었습니다."); break;
	            case 1: System.out.println("나이 제한으로 대여 불가능입니다."); break;
	            case 2: System.out.println("성공적으로 대여되었습니다. 요리학원 쿠폰이 발급되었으니 마이페이지에서 확인하세요."); break;
	        }
	        
	    }
	    
	
	
}
