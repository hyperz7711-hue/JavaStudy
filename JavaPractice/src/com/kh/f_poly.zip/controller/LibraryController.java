package com.kh.f_poly.controller;

import com.kh.f_poly.model.vo.AniBook;
import com.kh.f_poly.model.vo.Book;
import com.kh.f_poly.model.vo.CookBook;
import com.kh.f_poly.model.vo.Member;

public class LibraryController {
    private Member mem = null;
    private Book[] bList = new Book[5];

    {
        bList[0] = new CookBook("백종원의 집밥", "백종원", "tvN", true);
        bList[1] = new AniBook("한번 더 해요", "미티", "원모어", 19);
        bList[2] = new AniBook("루피의 원피스", "루피", "japan", 12);
        bList[3] = new CookBook("이혜정의 얼마나 맛있게요", "이혜정", "문학", false);
        bList[4] = new CookBook("최현석 날 따라해봐", "최현석", "소금책", true);
    }

    public void insertMember(Member mem) {
        this.mem = mem;
    }

    public Member myInfo() {
        return mem;
    }

    public Book[] selectAll() {
        return bList;
    }

    public Book[] searchBook(String keyword) {
    	
    	// 검색 결과를 담아줄 새로운 Book 객체 배열 생성
    	// 검색 결과 도서 목록이 최대 5개일 수 있으니 임의로 크기 5 할당
        Book[] searchList = new Book[5];
        int count = 0;

    	// for문을 이용하여 bList 도서 목록들의 도서명과 전달받은 keyword 비교
    	// 전달받은 keyword를 포함하고 있으면 → HINT : String 클래스의 contains() 참고
    	// 검색결과의 도서목록에 담기 → HINT : count 이용

        for (Book b : bList) {    	
        	// contains 함수를 통해서 포함된 문자열 체크 가능 : DB시 배우는 LIKE '%' +'키워드' + '%' 와 동일
            if (b.getTitle().contains(keyword)) {
            	// 포함된 문자열이 있을 때마다 인덱스를 증가하여 입력
                searchList[count++] = b;
            }
        }
    	// 해당 검색결과의 도서목록 주소 값 리턴  	        
        // 향상된 for문 사용 클래스배열을 조회하기 때문에 변수타입은 배열 : 클래스배열에서 조회      
        return searchList;
    }

    public int rentBook(int index) {
    	
    	// int result = 0;

    	// result 값 리턴  	
        int result = 0;

    	// 전달 받은 index의 bList 객체가 만화책을 참조하고 있고
    	// 해당 만화책의 제한 나이와 회원의 나이를 비교하여 회원 나이가 적을 경우
    	// result를 1로 초기화 → 나이제한으로 대여 불가
     
        Book b = bList[index];
        if (b instanceof AniBook) {
            AniBook ab = (AniBook) b;
            if (mem.getAge() < ab.getAccessAge()) {
                result = 1; // 나이 제한
            }
        } 
    	// 전달 받은 index의 bList 객체가 요리책을 참조하고 있고
    	// 해당 요리책의 쿠폰유무가 “유”일 경우
    	// 회원의 couponCount 1 증가 처리 후
    	// result를 2로 초기화 → 성공적으로 대여 완료, 요리학원 쿠폰 발급    
        else if (b instanceof CookBook) {
            CookBook cb = (CookBook) b;
            if (cb.isCoupon()) {
                mem.setCouponCount(mem.getCouponCount() + 1);
                result = 2; // 쿠폰 발급
            }
        }
        return result;
    }
}
