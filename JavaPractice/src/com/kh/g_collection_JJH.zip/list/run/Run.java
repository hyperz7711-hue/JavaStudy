package com.kh.g_collection.list.run;

import com.kh.g_collection.list.music.view.MusicView;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MusicView excute = new MusicView();
		
		excute.mainMenu();		

	}

}
