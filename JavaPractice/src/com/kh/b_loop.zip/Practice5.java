package com.kh.b_loop;

import java.util.Scanner;

public class Practice5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		method1();

	}
	
	public static void method1() {
		
		Scanner sc = new Scanner(System.in);	
		
		System.out.print("정수 입력 :");
		
		int num1 = sc.nextInt();
				
		
		for (int i = 0; i < num1; i++) {
							
			for(int j = num1 ; j > i  ; j--){
				
				System.out.print("*");
			}			
			System.out.println();
		}
		
		sc.close();
		
	}	

}